
import 'dart:io';
import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:osborn_book/pdf/search_toolbar.dart';
import 'package:path_provider/path_provider.dart';
import 'package:provider/provider.dart';
import 'package:sqflite/sqflite.dart';
import 'package:syncfusion_flutter_pdfviewer/pdfviewer.dart';

import '../HighLightsPage.dart';
import 'app_state.dart';
import 'bookmark.dart';
import 'bookmark_page.dart';
import 'grid_page.dart';
import 'highlights_page.dart';
import 'notes_page.dart';

class PdfViewerPage extends StatefulWidget {
  final String title;
  final String imagePath;
  final String url;
  final String urlToPdf;

  const PdfViewerPage({
    required this.title,
    required this.imagePath,
    required this.url,
    required this.urlToPdf,
  });

  @override
  _PdfViewerPageState createState() => _PdfViewerPageState();
}

class _PdfViewerPageState extends State<PdfViewerPage> {
  String pdfPath = ''; // Store the local path of the cached PDF.
  bool isLoading = true;
  double downloadProgress = 0.0; // Variable to track the download progress.
  bool isDownloaded = false; // Track if the file is downloaded to app storage
  bool showDialogOnce = false; // Prevent multiple dialog calls

  //// copied code
  int _selectedIndex = 0;
  final PdfViewerController _pdfViewerController = PdfViewerController();
  final GlobalKey<SfPdfViewerState> _pdfViewerKey = GlobalKey();
  final GlobalKey<SearchToolbarState> _textSearchKey = GlobalKey();
  PdfTextSelectionChangedDetails? _selectionDetails;
  late bool _showToolbar;
  late bool _showScrollHead;
  LocalHistoryEntry? _historyEntry;

  Future<void> initializeDb() async {
    Directory documentsDirectory = await getApplicationDocumentsDirectory();
    String path = documentsDirectory.path + "app_data.db";
    Database database = await openDatabase(
      path,
      version: 1,
      onCreate: (Database db, int version) async {
        // Create new tables
        await db.execute(
            "CREATE TABLE Highlights (id INTEGER PRIMARY KEY, pageNumber INTEGER, text TEXT, x REAL, y REAL, width REAL, height REAL, color INTEGER)");
        await db.execute(
            "CREATE TABLE Notes (id INTEGER PRIMARY KEY, pageNumber INTEGER, text TEXT, note TEXT, x REAL, y REAL, color INTEGER)");
        await db.execute(
            "CREATE TABLE BookMarks (id TEXT PRIMARY KEY, pageNumber INTEGER)");
        await db.execute(
            "CREATE TABLE Mark (id INTEGER PRIMARY KEY, pageNumber INTEGER, x REAL, y REAL)");
      },
    );
    Provider.of<AppState>(context, listen: false).setDatabase(database);
  }

  void _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
    });
  }

  void ensureHistoryEntry() {
    if (_historyEntry == null) {
      final ModalRoute<dynamic>? route = ModalRoute.of(context);
      if (route != null) {
        _historyEntry = LocalHistoryEntry(onRemove: _handleHistoryEntryRemoved);
        route.addLocalHistoryEntry(_historyEntry!);
      }
    }
  }

  void _handleHistoryEntryRemoved() {
    _textSearchKey.currentState?.clearSearch();
    setState(() {
      _showToolbar = false;
    });
    _historyEntry = null;
  }

  void _showBookmarks() async {
    final selectedPage = await Navigator.push(
      context,
      MaterialPageRoute(builder: (context) => BookmarksPage()),
    );
    if (selectedPage != null) {
      _pdfViewerController.jumpToPage(selectedPage);
    }
  }

  late List<int> myanno;

  // HIGLIGHT
  // Widget _buildPdfViewer() {
  //   return Stack(children: [
  //     Column(
  //       children: [
  //         Expanded(
  //           child: SfPdfViewer.file(
  //             File(pdfPath),
  //             controller: _pdfViewerController,
  //             key: _pdfViewerKey,
  //             pageLayoutMode: PdfPageLayoutMode.single,
  //
  //             onAnnotationAdded: (Annotation annotation) {
  //               print(annotation);
  //               // print("hellojyghnyhy ${_pdfViewerController.exportFormData(dataFormat: DataFormat.xfdf )}");
  //               Provider.of<AppState>(context, listen: false)
  //                   .addHighlight(
  //                 _pdfViewerController.pageNumber,
  //                 Provider.of<AppState>(context, listen: false).raam,
  //               );
  //
  //             },
  //             onTextSelectionChanged: (PdfTextSelectionChangedDetails details) {
  //               print("fjowejfowijfoqjfo ${_pdfViewerKey.currentState?.getSelectedTextLines()}");
  //               final annotations = details.globalSelectedRegion;
  //               print(annotations);
  //               if (details.selectedText != null && details.selectedText!.isNotEmpty) {
  //                 setState(() {
  //                   _selectionDetails = details;
  //                   Provider.of<AppState>(context, listen: false)
  //                       .updateData(_selectionDetails!.selectedText as String);
  //
  //                 });
  //
  //               }
  //             },
  //           ),
  //         ),
  //
  //
  //
  //
  // // REMOVE HIGLIGHT
  //
  //
  //         Visibility(
  //           visible: _textSearchKey.currentState?.showToast ?? false,
  //           child: Align(
  //             alignment: Alignment.center,
  //             child: Flex(
  //               direction: Axis.horizontal,
  //               mainAxisAlignment: MainAxisAlignment.center,
  //               children: <Widget>[
  //                 Container(
  //                   padding:
  //                   const EdgeInsets.only(left: 15, top: 7, right: 15, bottom: 7),
  //                   decoration: BoxDecoration(
  //                     color: Colors.grey[600],
  //                     borderRadius: const BorderRadius.all(
  //                       Radius.circular(16.0),
  //                     ),
  //                   ),
  //                   child: const Text(
  //                     'No result',
  //                     textAlign: TextAlign.center,
  //                     style: TextStyle(
  //                         fontFamily: 'Roboto',
  //                         fontSize: 16,
  //                         color: Colors.white),
  //                   ),
  //                 ),
  //               ],
  //             ),
  //           ),
  //         ),
  //         if (_selectionDetails != null &&
  //             _selectionDetails!.selectedText != null)
  //           Container(
  //             color: Colors.grey[200],
  //             child: Row(
  //               children: [
  //                 IconButton(
  //                   icon: Icon(Icons.highlight),
  //                   onPressed: () {
  //                     Provider.of<AppState>(context, listen: false)
  //                         .addHighlight(
  //                       _pdfViewerController.pageNumber!,
  //                       _selectionDetails!.selectedText!,
  //                     );
  //                     ScaffoldMessenger.of(context).showSnackBar(
  //                         SnackBar(content: Text("Text highlighted!")));
  //                     _selectionDetails = null;
  //                     setState(() {});
  //                   },
  //                 ),
  //                 IconButton(
  //                   icon: Icon(Icons.note_add),
  //                   onPressed: () {
  //                     _addNoteDialog(_pdfViewerController.pageNumber!,
  //                         _selectionDetails!.selectedText!);
  //                   },
  //                 ),
  //               ],
  //             ),
  //           ),
  //       ],
  //     ),
  //   ]);
  // }

  // Widget _buildPdfViewer() {
  //   return Stack(children: [
  //     Column(
  //       children: [
  //         Expanded(
  //           child: SfPdfViewer.file(
  //             File(pdfPath),
  //             controller: _pdfViewerController,
  //             key: _pdfViewerKey,
  //             pageLayoutMode: PdfPageLayoutMode.single,
  //
  //             // When annotation is added (e.g., highlight)
  //             onAnnotationAdded: (Annotation annotation) {
  //               print("[Highlight Specifications] Annotation Added: $annotation");
  //               print("[Highlight Specifications] Current Page Number: ${_pdfViewerController.pageNumber}");
  //               print("[Highlight Specifications] Raam Value: ${Provider.of<AppState>(context, listen: false).raam}");
  //
  //               // Update the state with the new highlight
  //               if (_selectionDetails != null) {
  //                 final Rect? region = _selectionDetails!.globalSelectedRegion;
  //
  //                 if (region != null) {
  //                   final double x = region.left;
  //                   final double y = region.top;
  //                   final double width = region.width;
  //                   final double height = region.height;
  //                   final int color = annotation.color.value;
  //
  //
  //
  //                   Provider.of<AppState>(context, listen: false).addHighlight(
  //                     _pdfViewerController.pageNumber ?? 1, // Ensure non-null page number
  //                     Provider.of<AppState>(context, listen: false).raam,
  //                     x, y, width, height, color,
  //                   );
  //                 }
  //               }
  //             },
  //
  //             // When text selection is changed
  //             onTextSelectionChanged: (PdfTextSelectionChangedDetails details) {
  //               print("[Text Selection Specifications] Text Selection Changed!");
  //               print("[Text Selection Specifications] Selected Text: ${details.selectedText}");
  //               print("[Text Selection Specifications] Global Selected Region: ${details.globalSelectedRegion}");
  //               print("[Text Selection Specifications] Text Selection Details: ${details.toString()}");
  //
  //               if (details.selectedText != null && details.selectedText!.isNotEmpty) {
  //                 setState(() {
  //                   _selectionDetails = details;
  //                   print("[Text Selection Specifications] Updating Data with Selected Text: ${_selectionDetails!.selectedText}");
  //
  //                   // Update the state with the selected text
  //                   Provider.of<AppState>(context, listen: false)
  //                       .updateData(_selectionDetails!.selectedText as String);
  //                 });
  //               }
  //             },
  //           ),
  //         ),
  //
  //         // REMOVE HIGHLIGHT
  //         Visibility(
  //           visible: _textSearchKey.currentState?.showToast ?? false,
  //           child: Align(
  //             alignment: Alignment.center,
  //             child: Flex(
  //               direction: Axis.horizontal,
  //               mainAxisAlignment: MainAxisAlignment.center,
  //               children: <Widget>[
  //                 Container(
  //                   padding: const EdgeInsets.only(left: 15, top: 7, right: 15, bottom: 7),
  //                   decoration: BoxDecoration(
  //                     color: Colors.grey[600],
  //                     borderRadius: const BorderRadius.all(Radius.circular(16.0)),
  //                   ),
  //                   child: const Text(
  //                     'No result',
  //                     textAlign: TextAlign.center,
  //                     style: TextStyle(
  //                       fontFamily: 'Roboto',
  //                       fontSize: 16,
  //                       color: Colors.white,
  //                     ),
  //                   ),
  //                 ),
  //               ],
  //             ),
  //           ),
  //         ),
  //
  //         // Display the row of icons (highlight and add note)
  //         if (_selectionDetails != null && _selectionDetails!.selectedText != null)
  //           Container(
  //             color: Colors.grey[200],
  //             child: Row(
  //               children: [
  //                 IconButton(
  //                   icon: Icon(Icons.highlight),
  //                   onPressed: () {
  //                     print("[Highlight Specifications] Highlighting Text: ${_selectionDetails!.selectedText}");
  //
  //                     // Add the highlight to the app state
  //                     final Rect? region = _selectionDetails!.globalSelectedRegion;
  //                     if (region != null) {
  //                       final double x = region.left;
  //                       final double y = region.top;
  //                       final double width = region.width;
  //                       final double height = region.height;
  //                       final int color = Colors.yellow.value;
  //
  //                       Provider.of<AppState>(context, listen: false).addHighlight(
  //                         _pdfViewerController.pageNumber ?? 1, // Ensure non-null page number
  //                         _selectionDetails!.selectedText!,
  //                         x, y, width, height, color,
  //                       );
  //                     }
  //
  //                     // Show a Snackbar to confirm highlighting
  //                     ScaffoldMessenger.of(context).showSnackBar(
  //                         SnackBar(content: Text("Text highlighted!")));
  //                     _selectionDetails = null;
  //                     setState(() {});
  //                   },
  //                 ),
  //                 IconButton(
  //                   icon: Icon(Icons.note_add),
  //                   onPressed: () {
  //                     print("[Note Specifications] Adding Note for Text: ${_selectionDetails!.selectedText}");
  //
  //                     // Open the note dialog for adding a note
  //                     _addNoteDialog(
  //                       _pdfViewerController.pageNumber!,
  //                       _selectionDetails!.selectedText!,
  //                     );
  //                   },
  //                 ),
  //               ],
  //             ),
  //           ),
  //       ],
  //     ),
  //   ]);
  // }

  Widget _buildPdfViewer() {
    return Stack(children: [
      Column(
        children: [
          Expanded(
            child: SfPdfViewer.file(
              File(pdfPath),
              controller: _pdfViewerController,
              key: _pdfViewerKey,
              pageLayoutMode: PdfPageLayoutMode.single,

              // When annotation is added (e.g., highlight)
              onAnnotationAdded: (Annotation annotation) {
                print("[Highlight] Annotation Added: $annotation");
                print("[Highlight] Page Number: ${_pdfViewerController.pageNumber}");
                print("[Highlight] Raam Value: ${Provider.of<AppState>(context, listen: false).raam}");

                if (_selectionDetails != null) {
                  final Rect? region = _selectionDetails!.globalSelectedRegion;

                  if (region != null) {
                    final double x = region.left;
                    final double y = region.top;
                    final double width = region.width;
                    final double height = region.height;
                    final int color = annotation.color.value;

                    print("[Highlight] Highlighting Region -> X: $x, Y: $y, Width: $width, Height: $height, Color: $color");

                    Provider.of<AppState>(context, listen: false).addHighlight(
                      _pdfViewerController.pageNumber ?? 1,
                      Provider.of<AppState>(context, listen: false).raam,
                      x, y, width, height, color,
                    );

                    print("[Highlight] Highlight saved in AppState");
                  } else {
                    print("[Highlight] No valid region found for highlighting.");
                  }
                }
              },

              // When text selection is changed
              onTextSelectionChanged: (PdfTextSelectionChangedDetails details) {
                print("[Text Selection] Text Selection Changed!");
                print("[Text Selection] Selected Text: ${details.selectedText}");
                print("[Text Selection] Global Region: ${details.globalSelectedRegion}");
                print("[Text Selection] Details: ${details.toString()}");

                if (details.selectedText != null && details.selectedText!.isNotEmpty) {
                  setState(() {
                    _selectionDetails = details;
                    print("[Text Selection] Updated State with Selected Text: ${_selectionDetails}");
                    print("[Text Selection] Updated State with Selected Text: ${_selectionDetails!.selectedText}");

                    Provider.of<AppState>(context, listen: false)
                        .updateData(_selectionDetails!.selectedText as String);

                    print("[Text Selection] Data updated in AppState.");
                  });
                } else {
                  print("[Text Selection] No valid text selection.");
                }


              },
            ),
          ),

        ],
      ),
    ]);
  }


  void _showHighlights() async {
    final result = await Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => HighlightsPage(
          // Pass the highlights data to HighlightsPage
          onViewHighlight: (pageNumber, text, x, y, width, height, color) {
            // Jump to the specific page
            _pdfViewerController.jumpToPage(pageNumber);

            // Optional: Scroll to the highlight position
            // You may need to convert the coordinates to the current view

            // Show a temporary indicator of where the highlight is
            ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(
                  content: Text('Viewing highlight: "$text"'),
                  backgroundColor: Color(color),
                  duration: Duration(seconds: 2),
                )
            );
          },
        ),
      ),
    );

    // If a simple page number was returned instead of using the callback
    if (result != null && result is int) {
      _pdfViewerController.jumpToPage(result);
    }
  }

  // void _showHighlights() async {
  //   final selectedPage = await Navigator.push(
  //     context,
  //     MaterialPageRoute(builder: (context) => HighlightsPage()),
  //   );
  //   if (selectedPage != null) {
  //     _pdfViewerController.jumpToPage(selectedPage);
  //   }
  // }

  void _showNotes() async {
    final selectedPage = await Navigator.push(
      context,
      MaterialPageRoute(builder: (context) => NotesPage()),
    );
    if (selectedPage != null) {
      _pdfViewerController.jumpToPage(selectedPage);
    }
  }

  void _addNoteDialog(int pageNumber, String selectedText) {
    TextEditingController noteController = TextEditingController();
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text("Add a Note"),
        content: TextField(
          controller: noteController,
          decoration: InputDecoration(hintText: "Enter your note here"),
        ),
        actions: [
          TextButton(
            onPressed: () async {
              await Provider.of<AppState>(context, listen: false).addNote(
                pageNumber,
                selectedText,
                noteController.text,
              );
              Navigator.of(context).pop();
              ScaffoldMessenger.of(context)
                  .showSnackBar(SnackBar(content: Text("Note added!")));
            },
            child: Text("Save"),
          ),
        ],
      ),
    );
  }

  // void _addHighlight() {
  //   if (_selectionDetails != null && _selectionDetails!.selectedText != null) {
  //     final pageNumber = _pdfViewerController.pageNumber!;
  //     final selectedText = _selectionDetails!.selectedText!;
  //
  //     // // Add visual highlight
  //     // _pdfViewerController.addHighlight(_selectionDetails!);
  //
  //     // Save highlight to AppState
  //     Provider.of<AppState>(context, listen: false).addHighlight(
  //       pageNumber,
  //       selectedText,
  //     );
  //
  //     ScaffoldMessenger.of(context).showSnackBar(
  //       SnackBar(content: Text('Text highlighted')),
  //     );
  //
  //     // Clear selection
  //     setState(() {
  //       _selectionDetails = null;
  //     });
  //   }
  // }

  ///////////////////

  @override
  void initState() {
    _showToolbar = false;
    _showScrollHead = true;
    super.initState();
    initializeDb();
    if (widget.urlToPdf.isEmpty) {
      setState(() {
        isLoading = false; // Set loading to false to show the image
      });
      WidgetsBinding.instance.addPostFrameCallback((_) {
        _showNoPdfAvailableDialog(); // Show dialog after the frame is built
      });
    } else {
      fetchAndCachePdf();
    }
  }

  // Function to download and cache the PDF file.
  Future<void> fetchAndCachePdf() async {
    try {
      WidgetsFlutterBinding.ensureInitialized();
      Directory cacheDir = await getTemporaryDirectory();
      String filePath = '${cacheDir.path}/${widget.title}.pdf';

      // Check if the file already exists in the cache.
      if (File(filePath).existsSync()) {
        setState(() {
          pdfPath = filePath;
          isLoading = false;
        });
      } else {
        Dio dio = Dio();
        String url = widget.urlToPdf; // Use the non-null url

        await dio.download(
          url,
          filePath,
          onReceiveProgress: (receivedBytes, totalBytes) {
            if (totalBytes != -1) {
              setState(() {
                downloadProgress = (receivedBytes / totalBytes) * 100;
              });
            }
          },
        );

        setState(() {
          pdfPath = filePath;
          isLoading = false;
        });
      }
    } catch (e) {
      setState(() {
        isLoading = false;
      });
      showErrorDialog(e.toString());
    }
  }

  // Function to show a dialog when no PDF is available
  void _showNoPdfAvailableDialog() {
    if (!showDialogOnce) {
      showDialog(
        context: context,
        builder: (context) => AlertDialog(
          title:const Text('No PDF Available'),
          content: const Text('Currently, no PDF is available.'),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(context).pop(),
              child: const Text('OK'),
            ),
          ],
        ),
      );
      showDialogOnce = true; // Ensure dialog is shown only once
    }
  }

  // Function to save the cached PDF to the application's document directory.
  Future<void> savePdfToDocuments() async {
    try {
      Directory appDocDir = await getApplicationDocumentsDirectory();
      String appFilePath = '${appDocDir.path}/${widget.title}.pdf';

      // Copy the cached PDF file to the application's document directory.
      File cachedPdf = File(pdfPath);
      await cachedPdf.copy(appFilePath);

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('PDF downloaded to app\'s storage!'),
          duration: Duration(seconds: 2),
        ),
      );

      setState(() {
        isDownloaded = true;
      });
    } catch (e) {
      showErrorDialog(e.toString());
    }
  }

  // Show error dialog in case of failure.
  void showErrorDialog(String message) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('Error'),
        content: Text(message),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: Text('OK'),
          ),
        ],
      ),
    );
  }

  // @override
  // void dispose() {
  //   if (pdfPath.isNotEmpty) {
  //     final file = File(pdfPath);
  //     if (file.existsSync()) {
  //       file.deleteSync();
  //       print('Cached PDF file deleted.');
  //     }
  //   }
  //   super.dispose();
  // }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: _showToolbar ?
          AppBar(
            flexibleSpace: SafeArea(
                child: SearchToolbar(
                  key: _textSearchKey,
                  showTooltip: true,
                  controller: _pdfViewerController,
                  onTap: (Object toolbarItem) async {
                    if(toolbarItem.toString() == 'Cancel Search'){
                      setState(() {
                        _showToolbar = false;
                        _showScrollHead = true;
                        if(Navigator.canPop(context)){
                          Navigator.maybePop(context);
                        }
                      });
                    }
                    if(toolbarItem.toString() =='noResultFound'){
                      setState(() {
                        _textSearchKey.currentState?.showToast = true;
                      });
                      await Future.delayed(Duration(seconds: 1));
                      setState(() {
                        _textSearchKey.currentState?.showToast = false;
                      });
                    }
                  },
                ),
            ),
            automaticallyImplyLeading: false,
            backgroundColor: Colors.deepPurple,
          )
      : AppBar(
        title:const Text(
          "Osborne",
          style: TextStyle(color: Colors.white),
        ),
        actions: [
          IconButton(
            icon: const Icon(
              Icons.search,
              color: Colors.white,
            ),
            onPressed: () {
              setState(() {
                _showScrollHead = false;
                _showToolbar = true;
                ensureHistoryEntry();
              });
            },
          ),
          IconButton(
              onPressed: _showBookmarks,
              icon: const Icon(Icons.bookmark, color: Colors.white),),
        ],
        automaticallyImplyLeading: false,
        backgroundColor: Colors.deepPurple,
      ),

      body: isLoading
          ? Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(
              'Loading: ${downloadProgress.toStringAsFixed(0)}%',
              style: TextStyle(fontSize: 18),
            ),
           const SizedBox(height: 20),
            CircularProgressIndicator(value: downloadProgress / 100),
          ],
        ),
      )
          : widget.urlToPdf.isEmpty
          ? Center(child: Image.network(widget.imagePath)) // Display the image if no PDF
          : Column(
        children: [
          Expanded(child: _buildPdfViewer()),
          Container(
            color: Colors.deepPurple,
            padding: const EdgeInsets.symmetric(vertical: 5, horizontal: 20),
            height: 60,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                IconButton(
                  icon:const Icon(
                    Icons.list,
                    color: Colors.white,
                    size: 28,
                  ),
                  onPressed: () {
                    _pdfViewerKey.currentState?.openBookmarkView();
                  },
                ),
                IconButton(
                  // Add this new IconButton for the grid view
                  icon: Icon(Icons.grid_view,
                      color: Colors.white, size: 28),
                  onPressed: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => PdfGridView(
                          pdfViewerController: _pdfViewerController,
                        ),
                      ),
                    );
                  },
                ),
                IconButton(
                  icon: Icon(
                    Icons.highlight_rounded,
                    color: Colors.white,
                  ),
                  onPressed: _showHighlights,
                ),
                IconButton(
                  icon:const Icon(
                    Icons.note,
                    color: Colors.white,
                  ),
                  onPressed: _showNotes,
                ),
                IconButton(
                  icon: Icon(
                    Icons.bookmark_add,
                    color: Colors.white,
                    size: 28,
                  ),
                  onPressed: () {
                    final currentPage = _pdfViewerController.pageNumber;
                    final bookmark = Bookmark(
                      id: 'page_$currentPage',
                      pageNumber: currentPage,
                    );

                    Provider.of<AppState>(context, listen: false)
                        .addBookmark(bookmark)
                        .then((_) {
                      ScaffoldMessenger.of(context).showSnackBar(
                        SnackBar(
                            content: Text('Page $currentPage bookmarked')),
                      );
                    });
                  },
                ),
                IconButton(
                  icon:const Icon(
                    Icons.download,
                    color: Colors.white,
                  ),
                  onPressed: () async {
                    if (pdfPath.isNotEmpty) {
                       await savePdfToDocuments();
                        }
                    },
                ),
              ],
            ),
          )
        ],
      ),
    );
  }

}
